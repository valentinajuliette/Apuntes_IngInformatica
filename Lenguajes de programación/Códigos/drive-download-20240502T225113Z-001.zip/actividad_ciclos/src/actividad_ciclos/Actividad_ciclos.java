/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad_ciclos;
import java.util.Scanner;

/**
 *
 * @author JoyOriana
 */
public class Actividad_ciclos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        String nombre;
        float nota = 0.0f,promedio =0.0f,sumatoria=0.0f;
        
        //Solicitar nombre
        System.out.println("Ingrese su nombre completo  ");
        nombre=sc.nextLine();
        
        for(int i=1;i<=5;i++){
            //Solicitar calificaciones
            System.out.println("Ingrese una nota");
            nota=sc.nextFloat();
            //sumar las notas ingresadas
            sumatoria=sumatoria+nota;
        }//fin for
        
        //Resultado
        promedio=(sumatoria/5);
        System.out.println("Su nombre es: "+nombre);
        System.out.println("El promedio obtenido es: "+promedio);
        
        //Mi nombre es Jocelyn Gonzalez y obtube un promedio de 6
        
    }//fin void
    
}//fin clase
