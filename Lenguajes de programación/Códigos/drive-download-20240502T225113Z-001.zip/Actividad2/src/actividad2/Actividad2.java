/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad2;
import java.util.Scanner;

/**
 *
 * @author JoyOriana
 */
public class Actividad2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        String nombre;
        float valor_compra, descuento=0, precio_final=0;
        
        System.out.println("ingrese el nombre del cliente: ");
        nombre=sc.nextLine();
        
        System.out.print("ingrese el Valor de la compra: ");
        valor_compra=sc.nextFloat();
        
        if(valor_compra<=80){
            descuento=0;
        }else if(valor_compra >80 && valor_compra<=170){ //se corrige signo de<80
           descuento=(float)0.15;
        }else if (valor_compra >170 && valor_compra <=350){
            descuento=(float) 0.2;
        }else if (valor_compra >350 && valor_compra <600){
            descuento=(float) 0.25;
        }
        
        precio_final=valor_compra-(valor_compra*descuento);
        
        System.out.println(
                "Nombre del cliente: " +nombre +"\n"+
                "Valor de compra: " +valor_compra +"\n"+
                "Valor compra con descuento: " +precio_final);
        }
    }
    
/*Lorena martinez realizó compra de 500 usd, valor compra con descuento 400 usd
  Angel González realizó compra de 75 usd, valor compra con descuento 75 usd, 
Sandra Ramirez realizó compra de 256 usd, valor compra con descuento 204.8 usd
Kelly Villa realizó compra de 304 usd, valor compra con descuento 243.2 usd*/
