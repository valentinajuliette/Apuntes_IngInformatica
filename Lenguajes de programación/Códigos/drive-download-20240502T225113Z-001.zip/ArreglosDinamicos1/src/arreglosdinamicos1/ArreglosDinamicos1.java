/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglosdinamicos1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author JoyOriana
 */
public class ArreglosDinamicos1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Array de tipo String
        List<String> animales = new ArrayList<>();
     /*  
        //Agregar ellemntos al Array
        animales.add("León");
        animales.add("Tigre");
        animales.add("Gato");
        animales.add("Perro");
        System.out.println("Primer Array "+animales);
        //al poner el 2 significa que el elemento se agrega en esa posición
        animales.add(2,"Elefante");
        System.out.println("Segundo Array "+animales);
        
        */
        List<String> lenguajesProgramacion = new ArrayList<>();
        lenguajesProgramacion.add("C++");
        lenguajesProgramacion.add("Python");
        lenguajesProgramacion.add("Java");
        lenguajesProgramacion.add("Ruby");
        
        System.out.println("Arreglo 1"+lenguajesProgramacion);
        
        //Remover elemento de la posicion 3 del arreglo
        lenguajesProgramacion.remove(3);
        System.out.println("Arreglo 2"+lenguajesProgramacion);
        
        //nota: No confundir este arreglo dinámico, con un aareglo
        
        //llenado dinamicamente, porque éste último es de tamaño fijo
        
    }//fin void main
    
}//fin clase
