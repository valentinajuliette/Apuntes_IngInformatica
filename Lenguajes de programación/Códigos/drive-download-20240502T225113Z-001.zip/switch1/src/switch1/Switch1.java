/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package switch1;

/**
 *
 * @author JoyOriana
 */
public class Switch1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        char vocal= 'O';
        switch(vocal){
            case 'A':
                System.out.println("caso A");
                break;//case a
            case 'E':
                System.out.println("caso E");
                break;//case e
            case 'I':
                System.out.println("caso I");
                break;//case i
            case 'O':
                System.out.println("caso O");
                break;//case o
            default:
                System.out.println("caso U");
                //case default
              
        }//fin switch
       
        String m;
        int mes=12;
        switch(mes){
            case 1:
                m="Enero";
                break;//case 1
            case 2:
                m="Febrero";
                break;//case 2
            case 10:
                m="Octubre";
                break;//case 10
            case 11:
                m="Noviembre";
                break;//case 11
            default:
                m="Diciembre";
                //case default
              
        }//fin switch
     System.out.println(m);
     
     
    }//fin void
    
}
