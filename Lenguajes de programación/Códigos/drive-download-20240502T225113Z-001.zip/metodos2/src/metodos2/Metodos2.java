
package metodos2;

/**
 *
 * @author JoyOriana
 */
public class Metodos2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         //se crea una instancia de la clase Operaciones2
        Operaciones2 op= new Operaciones2();
        op.Bienvenida();
        //en esta variante le damos los datos
        op.sumar(3,6);
        op.restar(8,5);
        op.resultado();
    }//fin void main
    
}//fin class Metodos2
