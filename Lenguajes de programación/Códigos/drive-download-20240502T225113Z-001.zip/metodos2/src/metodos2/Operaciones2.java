
package metodos2;

/**
 *
 * @author JoyOriana
 */
public class Operaciones2 {
    //Atributos
    int suma, resta;
    
    //creacion metodo bienvenida
    public void Bienvenida(){
        System.out.println("Bienvenidos al programa ");
    }//Fin metodo Bienvenida
    
    public void sumar(int numero1,int numero2){
        suma=numero1+numero2;
    }//fin metodo sumar
    
    public void restar(int numero1,int numero2){
        resta= numero1-numero2;
    }//fin metodo restar
    
    public void resultado(){
        System.out.println("Resultado suma "+suma);
        System.out.println("Resultado resta "+resta);
    }//fin metodo resultado
      
}//fin clase Operaciones2
