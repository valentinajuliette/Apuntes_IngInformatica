/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package creacionclase;

/**
 *
 * @author JoyOriana
 */
public class Asignatura {
    private String nombre;
    private String codigo;
    private int curso;
    
    public Asignatura(String _nombre,String _codigo, int _curso){
        this.nombre = _nombre;
        this.codigo = _codigo;
        this.curso = _curso;             
    
    }//fin constructor Asignatura
    
    //metodos set y get
    
    public String getNombre(){
        return nombre;
    
    }//get nombre
    
    public void setNombre(String nombre){
            this.nombre= nombre;
    }//fin setNombre
    
    public String getCodigo(){
        return codigo;
    }//fin getCodigo
    
    public void setCodigo(String codigo){
          this.codigo=codigo;
    }//fin void setCodigo
    
    public int getCurso(){
        return curso;
    }//fin getCurso
    
    public void setCurso(int curso){
        this.curso=curso;
    }//fin set Curso
    
    
    
}//fin public class Asignatura
