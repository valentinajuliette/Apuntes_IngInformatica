
package creacionclase;


public class CreacionClase {

   
    public static void main(String[] args) {
        // TODO code application logic here
        Asignatura asignatura_1= new Asignatura("Matematica", " Mt", 100);
        Asignatura asignatura_2= new Asignatura("Inglés"," Ig", 100);
        asignatura_1.setCurso(200);
        asignatura_2.setCodigo("In");
        
        //impresión de info de objetos:
        System.out.println("Nombre: "+asignatura_1.getNombre()+" Codigo "+asignatura_1.getCodigo()+"  Curso: "+asignatura_1.getCurso());
        
    }//fin void main
    
}//fin clase principal
