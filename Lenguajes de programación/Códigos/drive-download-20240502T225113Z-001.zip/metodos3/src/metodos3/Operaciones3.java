/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package metodos3;

/**
 *
 * @author JoyOriana
 */
public class Operaciones3 {
    //Atributos
    int suma, resta;
    
    //creacion metodo bienvenida
    public void Bienvenida(){
        System.out.println("Bienvenidos al programa ");
    }//Fin metodo Bienvenida
    
    public int sumar(int numero1,int numero2){
        suma=numero1+numero2;
        return suma;
    }//fin metodo sumar
    
    public int restar(int numero1,int numero2){
        resta= numero1-numero2;
        return resta;
    }//fin metodo restar
     
}//fin clase Operaciones3
