/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package metodos3;

/**
 *
 * @author JoyOriana
 */
public class Metodos3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         //se crea una instancia de la clase Operaciones
        Operaciones3 op= new Operaciones3();
        op.Bienvenida();
        
        //ahora se muestran los resultados
        System.out.println("Resultado suma "+op.sumar(8,6));
        System.out.println("Resultado resta "+  op.restar(5,6));
        
    }//fin void main
    
}//fin class
