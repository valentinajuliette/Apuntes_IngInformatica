
package while1;

/**
 *
 * @author JoyOriana
 */
public class While1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int n=4;
        while(n<=10){
            System.out.println(n);
            n++;
        }//fin while
    }
    
}
