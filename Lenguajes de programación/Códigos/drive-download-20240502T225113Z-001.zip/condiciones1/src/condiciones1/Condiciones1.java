/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package condiciones1;
import java.util.Scanner;
        
/**
 *
 * @author JoyOriana
 */
public class Condiciones1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Ingrese una edad: ");
        Scanner sc= new Scanner(System.in);
        int edad;
        edad = sc.nextInt();
        
        if(edad >=18){
            System.out.println("Adulto");
        }else{
            System.out.println("menor");
            }//fin else
    
    }//fin void main
    
}//fin class
