/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglos_unidimensionales1;

/**
 *
 * @author JoyOriana
 */
public class Arreglos_unidimensionales1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
     /*   int notas[]= new int[5];
        
        notas[0]=4;
        notas[1]=5;
        notas[2]=6;
        notas[3]=7;
        notas[4]=8;
        
        System.out.println("El numero es: "+notas[0]);*/
    
    int notas[]={4,5,6,7,8};
    
    for (int a=0;a<notas.length;a++){
        System.out.println("El numero es: "+notas[a]);
    
    
    }//fin for
    
        
        
        
    }//fin void
    
}//fin clase
