
package excepciones;

/**
 *
 * @author JoyOriana
 */
public class Excepciones {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try{
            System.out.println("Intentando Ejecutar Bloque");
            System.out.println("Instrucción 1 ");
            System.out.println("Instruccion 2 ");
            System.out.println("Instruccion 3 ");
            
            // mensaje justo antes de un error forzado
            System.out.println("Mensaje antes de ocurrido error");
            
            //Error forzado en tiempo de ejecucion
            int f= Integer.parseInt("N");
            
            //se salta este mensaje pues ocurrio un error
            System.out.println("Mensaje despues de ocurrido error");
            
        }catch(Exception e){
            System.out.println("El error es "+e);
        }//fin catch
        finally{
                System.out.println("Instrucciones finalizadas");
                }//fin finally
    }//fin void main
    
}//fin clase excepciones
