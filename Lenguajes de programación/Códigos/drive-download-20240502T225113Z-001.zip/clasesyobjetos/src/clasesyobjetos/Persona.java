package clasesyobjetos;

/**
 *
 * @author JoyOriana
 */
public class Persona {
    //Atributos
    String nombre;
    double estatura;
    int edad;
    
    //método constructor
    public Persona(String _nombre, double _estatura, int _edad){
        this.nombre=_nombre;
        this.estatura=_estatura;
        this.edad=_edad;
    
    }//fin metodo constructor
    
    public void imprimirDatos(){
        System.out.println("Nombre "+nombre);
        System.out.println("Estatura "+ estatura);
        System.out.println("Edad "+edad);
        
    }//fin imprimirDatos
    
}//fin clase Persona
