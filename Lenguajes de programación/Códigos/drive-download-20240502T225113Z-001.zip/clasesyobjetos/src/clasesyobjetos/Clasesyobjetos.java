
package clasesyobjetos;
/**
 *
 * @author JoyOriana
 */
public class Clasesyobjetos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona adulto = new Persona("Jose", 1.81, 90);
        adulto.imprimirDatos();
        
    }//fin void main
    
}//fin class
