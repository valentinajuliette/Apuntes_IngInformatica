
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad_operadores;

/**
 *
 * @author JoyOriana
 */
import java.util.Scanner;

public class Actividad_operadores {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);

        int primer_numero, segundo_numero;
        
        System.out.println("Ingresa el primer numero ");
        primer_numero = sc.nextInt();
        
        System.out.println("Ingresa el Segundo numero ");
        segundo_numero = sc.nextInt();
        //Suma
        System.out.println(primer_numero + segundo_numero);
        //multiplicación
        System.out.println(primer_numero * segundo_numero);
        //son iguales
        System.out.println(primer_numero == segundo_numero);
        //¿El primer numero es menor que el segundo?
        System.out.println(primer_numero < segundo_numero);
        //¿El segundo numero es mayor o igual que el primero?
        System.out.println(segundo_numero >= primer_numero);

    }//fin void main

}//fin class
