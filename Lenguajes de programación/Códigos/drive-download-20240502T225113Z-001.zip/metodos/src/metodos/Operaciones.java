
package metodos;

/**
 *
 * @author JoyOriana
 */
public class Operaciones {
    //Atributos
    int numero1=2;
    int numero2=4;
    int suma, resta;
    
    //creacion metodo bienvenida
    public void Bienvenida(){
        System.out.println("Bienvenidos al programa ");
    }//Fin metodo Bienvenida
    
    public void sumar(){
        suma=numero1+numero2;
    }//fin metodo sumar
    
    public void restar(){
        resta= numero1-numero2;
    }//fin metodo restar
    
    public void resultado(){
            System.out.println("Resultado suma "+suma);
            System.out.println("Resultado resta "+resta);
    }//fin metodo resultado
    
}//fin class Operaciones
