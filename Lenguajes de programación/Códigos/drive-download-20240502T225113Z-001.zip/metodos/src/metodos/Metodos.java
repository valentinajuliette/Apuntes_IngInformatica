
package metodos;

/**
 *
 * @author JoyOriana
 */
public class Metodos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //se crea una instancia de la clase Operaciones
        Operaciones op= new Operaciones();
        op.Bienvenida();
        op.sumar();
        op.restar();
        op.resultado();
        
    }//void main
    
}//fin class
