/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad_estructura_datos;
import java.util.Scanner;

/**
 *
 * @author JoyOriana
 */
public class Actividad_estructura_datos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc= new Scanner(System.in);
        
        //crear dos tipos de arreglos
        String[] empleados= new String[5];
        double[] sueldos =  new double[5];
        
        //Definir las variables
        double sumatoria=0.0, promedio=0.0, mayor=0.0;
        int posicion=0;
        
        //solicitar datos
        for (int i=0;i<5;i++){
            System.out.println("Ingrese un nombre: ");
            empleados[i]= sc.next();
            
            System.out.println("Ingrese el sueldo del empleado: "+empleados[i]);
            sueldos[i]=sc.nextDouble();
            
            //sumar los numeros ingresados
            sumatoria=sumatoria+sueldos[i];
        
            
        }//fin for
        
        //obtener promedio
        promedio=sumatoria/5;
        
        //Suponer que el numero mayor es el primer sueldo que se ingresó
        mayor=sueldos[0];
        
        for(int r=0;r<sueldos.length;r++){
            //obtener numero mayor
            if(sueldos[r]>mayor){
                mayor=sueldos[r];
                posicion=r;
            }//fin if
        }//fin for r
        
        //mostrar los resultados
        System.out.println(empleados[posicion]+" es el empleado con mayor sueldo y gana: "+mayor);
        System.out.println("El promedio de sueldos es: "+promedio);
        
        /*Elias es el empleado con mayor sueldo y gana: 2300
        
        El promedio de sueldos es: 1570 */
        
    }//fin void main
    
}//fin class
