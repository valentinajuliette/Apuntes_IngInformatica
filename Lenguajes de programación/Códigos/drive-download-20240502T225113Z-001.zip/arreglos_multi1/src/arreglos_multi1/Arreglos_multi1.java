/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package arreglos_multi1;

/**
 *
 * @author JoyOriana
 */
public class Arreglos_multi1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
   /*      int [][] numeros = new int [3][3];
         int f,c; //f filas , c columnas
    //recorrer filas
    for (f=0;f<numeros.length;f++){
        System.out.println();
        //recorrer columnas
        for(c=0;c<numeros.length;c++){
            System.out.print(numeros[f][c]);
            
        }//fin for c
        
    }//fin for f
    */
    //nueva
        int [][] numeros = new int [2][2];
         int f,c; //f filas , c columnas
         
         numeros[0][0]=45;
         numeros[0][1]=4;
         numeros[1][0]=78;
         numeros[1][1]=65;
                 
         
         
    //recorrer filas
    for (f=0;f<numeros.length;f++){
        System.out.println();
        //recorrer columnas
        for(c=0;c<numeros.length;c++){
            System.out.print(" "+numeros[f][c]);
            
        }//fin for c
        
    }//fin for f
    
     System.out.println();   
    }//fin void
    
}//fin clase
