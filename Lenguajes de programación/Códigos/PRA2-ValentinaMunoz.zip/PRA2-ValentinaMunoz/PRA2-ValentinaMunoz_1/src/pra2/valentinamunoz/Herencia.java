/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pra2.valentinamunoz;

// Se ejecuta la función para herecia
public class Herencia extends JAVAUSM {
    
    public void ImprimirMensaje() {
        System.out.println("Hola, estoy mandando este mensaje desde el archivo HERENCIA extends JAVAUSM :) ");
    }
    
} // fin de la clase
