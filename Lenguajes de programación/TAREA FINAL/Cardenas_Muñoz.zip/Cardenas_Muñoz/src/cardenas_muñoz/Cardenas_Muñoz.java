package cardenas_muñoz;

/*
    Tarea final: LENGUAJES DE PROGRAMACIÓN.
    Realizado en pareja por:
        - Valentina Muñoz.
        - Natalia Cárdenas.
 */

public class Cardenas_Muñoz {

    public static void main(String[] args) {

        /*
        TEMÁTICA DEL PROYECTO:
        Para nuestra tarea final, decidimos aplicar los conocimientos adquiridos a una problemática real:
        la mamá de Valentina tiene una casa de moda, que reúne diversas marcas de diseñador, y que
        actualmente gestiona su inventario con un sistema de código por producto (SKU) en un excel que
        se actualiza manualmente cada fin de mes, donde también de manera manual se calcula cada uno de
        los datos de facturación por concepto de ventas totales por marca.
        
        En este proyecto, decidimos sistematizar el proceso como modo de prueba :)
        
        DETALLES TÉCNICOS DEL PROYECTO:
        - El proyecto debe llevar por nombre los apellidos de los alumnos: HECHO.
        - El proyecto debe usar al menos 6 elementos distintos del menú (mostrado en la imagen), uno de ellos
        debe ser Table. Cuando se dice usar, no es solo que aparezca, sino que permita hacer alguna acción.
        Solamente los elementos botón o menú que realizan acciones diferentes de tipo CRUD, se cuentan con
        puntaje por separado como “distintos”: HECHO.
            - Elementos utilizados: PANEL, LABEL, BOTÓN, TEXT FIELD, COMBO BOX, SEPARATOR, TABLE, DIALOG.
        - Incluye elementos/acciones decorativos visuales: se aprecia orden y se evidencia cambio de
        colores(distintos al gris): HECHO.
        - Utiliza como parte de las acciones al menos una de las siguientes instrucciones:
        if/else/ciclos/listas/archivos: HECHO.
            - Se utilizaron todas, excepto archivos.
        - Usa alguna convención para dar nombre a sus variables: HECHO.
            - Utilizamos CAMEL CASE.
        - Hay comentarios agregados por los estudiantes en el Código: HECHO.

        */
        
    }
    
}
