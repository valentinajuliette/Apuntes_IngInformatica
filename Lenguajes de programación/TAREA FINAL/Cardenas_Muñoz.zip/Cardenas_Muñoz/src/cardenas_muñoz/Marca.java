package cardenas_muñoz;

import java.util.ArrayList;
import java.util.List;

public class Marca {
    
    // Atributos
    String nombreMarca;
    String codigo;
    String nombreContacto;
    String correo;
    String telefono;
    int comisionVenta;
    
    // Método constructor
    public Marca(String _nombreMarca, String _codigo, String _nombreContacto, String _correo, String _telefono, int _comisionVenta) {
        this.nombreMarca = _nombreMarca;
        this.codigo = _codigo;
        this.nombreContacto = _nombreContacto;
        this.correo = _correo;
        this.telefono = _telefono;
        this.comisionVenta = _comisionVenta;
    }
    
    // Lista que reúne todas las marcas existentes
    public static List<Marca> marcas = new ArrayList<>();
    
    // Función para añadir marca a la lista
    public static void agregarMarcas(Marca marca) {
        marcas.add(marca);
    }
    
    // Función que permite buscar una determinada marca entre las existentes
    public static Marca buscarMarca(String nombreMarca) {
        for (Marca marca : marcas) {
            if (marca.nombreMarca.equals(nombreMarca)) {
                return marca;
            }
        }
        return null;
    }
    
    // Método para retornar la lista actualizada de marcas
    public static List<Marca> leerMarcas() {
        return marcas;
    }

} // fin de la clase
