package cardenas_muñoz;

import java.util.ArrayList;
import java.util.List;

public class Producto {
    
    // Atributos
    String SKU; // Código identificador del producto
    Marca marca;
    String nombreProducto;
    int precio;
    String talla;
    int stock;
    
    // Método constructor
    public Producto(String _SKU, Marca _marca, String _nombreProducto, int _precio, String _talla, int _stock) {
        this.SKU = _SKU;
        this.marca = _marca;
        this.nombreProducto = _nombreProducto;
        this.precio = _precio;
        this.talla = _talla;
        this.stock = _stock;
    }
    
    // Lista que réune todos los productos existentes
    private static List<Producto> inventario = new ArrayList<>();
    
    // Función para añadir producto a la lista (inventario)
    public void agregarProducto(Producto producto) {
        inventario.add(producto);
    }
    
    // Listas que reúnen todos los productos vendidos
    public static List<String> skuVendidos = new ArrayList<>(); // En formato SKU
    public static List<Producto> productosVendidos = new ArrayList<>(); // En formato producto
    
    // Función para añadir un producto vendido a las listas (en ambos formatos)
    public static void venderProducto(String SKU) {
        skuVendidos.add(SKU);
        for (Producto producto : inventario) {
            if (producto.SKU.equals(SKU)) {
                productosVendidos.add(producto);
            }
        }
    }
    
    // Función que actualiza el stock de un producto que acaba de venderse
    public static void actualizarInventario() {
        for (String productoVendido : skuVendidos) {
            for (Producto producto : inventario) {
                if (producto.SKU.equals(productoVendido)) {
                    producto.stock--;
                }
            }
        }
    }
    
    // Función que permite hallar el precio de un determinado producto
    public static int hallarPrecio(String SKU) {
        for (Producto producto : inventario) {
            if (producto.SKU.equals(SKU)) {
                return producto.precio;
            }
        }
        return 0;
    }
    
    // Método para retornar la lista actualizada de productos vendidos
    public static List<Producto> cargarProductos() {
        return productosVendidos;
    }
}
