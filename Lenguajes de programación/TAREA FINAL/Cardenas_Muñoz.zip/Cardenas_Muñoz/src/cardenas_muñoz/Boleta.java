package cardenas_muñoz;

import java.util.ArrayList;
import java.util.List;

public class Boleta {
        
    // Atributos
    int numeroBoleta;
    Fecha fecha;
    int monto;
    List<String> productosBoleta; // Lista de SKU de los productos vendidos en la boleta
    
    // Se crea el método constructor
    public Boleta(int _numeroBoleta, Fecha _fecha, int _monto, List<String> _productosBoleta) {
        this.numeroBoleta = _numeroBoleta;
        this.fecha = _fecha;
        this.monto = _monto;
        this.productosBoleta = _productosBoleta;
    }
    
    // Lista que reúne todas las boletas existentes
    public static List<Boleta> boletas = new ArrayList<>();
    
    // Función para añadir boleta a la lista
    public static void añadirBoleta(Boleta boleta) {
        boletas.add(boleta);
    }
    
    // Función para calcular la suma de montos de todas las boletas
    public static int montoFinal() {
        int suma = 0;
        for (Boleta boleta : boletas) {
            suma += boleta.monto;
        }
        return suma;
    }
    
    // Método para retornar la lista actualizada de boletas
    public static List<Boleta> cargarBoletas() {
        return boletas;
    }
    
} // fin de la clase
