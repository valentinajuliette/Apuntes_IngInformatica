package cardenas_muñoz;

public class Fecha {

    // Atributos
    int dia;
    String mes;
    int año;

    // Método constructor
    public Fecha(int _dia, String _mes, int _año) {
        this.dia = _dia;
        this.mes = _mes;
        this.año = _año;
    }
}
